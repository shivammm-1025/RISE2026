# -*- coding: utf-8 -*-
"""KMEANS_clustering_assignment

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

df=pd.read_csv("/content/Mall_Customers.csv")
df.head()
x=df[['Annual Income (k$)','Spending Score (1-100)']]
scaler=StandardScaler()
x_scaled=scaler.fit_transform(x)

wcss=[]
for i in range(1,11):
  kmeans=KMeans(n_clusters=i,random_state=42)
  kmeans.fit(x_scaled)
  wcss.append(kmeans.inertia_)

plt.plot(range(1,11),wcss)
plt.xlabel("Clusters")
plt.ylabel("wcss")
plt.title("Elbow method")
plt.show()

kmeans=KMeans(n_clusters=5,random_state=42)
clusters=kmeans.fit_predict(x_scaled)
df['Cluster']=clusters
print(df.head())
score=silhouette_score(x_scaled,clusters)
print("Silhouette Score:",score)

plt.scatter(
    x['Annual Income (k$)'],
    x['Spending Score (1-100)'],
    c=clusters
)
plt.xlabel("Annual Income")

plt.ylabel("Spending Score")

plt.title("Customer Segmentation using K-Means")

plt.show()

"""## Evaluation Metrics

1. Elbow Method
The elbow method was used to determine the optimal number of clusters.
The graph showed an elbow point around K = 5, indicating the best cluster count.

2. Silhouette Score
Silhouette Score was used to evaluate clustering performance.
The score showed that the clusters were reasonably well separated and grouped.

## Business Metrics

1. Better Customer Segmentation
Customers were divided into groups based on spending behavior and income.

2. Improved Marketing
Businesses can target specific customer groups with personalized advertisements.

3. Increased Sales
Premium customers can be targeted with luxury offers and discounts.

4. Reduced Marketing Cost
Companies can focus advertisements only on important customer groups.

## Investor Benefits

1. Higher ROI (Return on Investment)
Targeted campaigns improve conversion rates and profits.

2. Better Business Decisions
Companies can understand customer behavior more effectively.

3. Customer Retention
Personalized services help retain valuable customers.

4. Profit Maximization
Businesses can identify high-spending customers and increase revenue.
"""