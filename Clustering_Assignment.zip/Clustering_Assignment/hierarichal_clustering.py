# -*- coding: utf-8 -*-
"""Hierarichal_Clustering



import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

df=pd.read_csv("/content/Mall_Customers.csv")
df.head()
x = df[['Annual Income (k$)', 'Spending Score (1-100)']]
scaler=StandardScaler()
x_scaled=scaler.fit_transform(x)
model=AgglomerativeClustering(n_clusters=5)
clusters=model.fit_predict(x_scaled)
df['Cluster']=clusters
print(df.head())
score=silhouette_score(x_scaled,clusters)
print("Silhouette Score",score)

plt.scatter(
    x['Annual Income (k$)'],
    x['Spending Score (1-100)'],
    c=clusters
)

plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title("Hierarchical Clustering")
plt.show()

"""## Evaluation Metrics

1. Silhouette Score was used to evaluate clustering quality.
2. Customers were grouped based on similarity.

## Business Metrics

1. Better customer understanding
2. Improved marketing strategy
3. Enhanced customer targeting

## Investor Benefits

1. Increased profitability
2. Better customer retention
3. Smarter decision-making
"""